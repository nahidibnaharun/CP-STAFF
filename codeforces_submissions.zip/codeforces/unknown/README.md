# Codeforces unknown Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 215 | [C - Pacer](https://codeforces.com/contest/2148/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2148/submission/338414825) |  | Sep/13/2025 08:59 PM |
| 214 | [B - Lasers](https://codeforces.com/contest/2148/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2148/submission/338384017) |  | Sep/13/2025 08:40 PM |
| 213 | [A - Sublime Sequence](https://codeforces.com/contest/2148/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2148/submission/338371567) |  | Sep/13/2025 08:36 PM |
| 212 | [K - Combination and Permutation](https://codeforces.com/contest/223338/problem/K) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/338368204) |  | Sep/13/2025 08:25 PM |
| 211 | [J - Prime Factors](https://codeforces.com/contest/223338/problem/J) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/338087611) |  | Sep/11/2025 07:39 PM |
| 210 | [C - Ultimate Value](https://codeforces.com/contest/2140/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2140/submission/337815143) | `data structures` `games` `greedy` | Sep/09/2025 09:31 PM |
| 209 | [B - Another Divisibility Problem](https://codeforces.com/contest/2140/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2140/submission/337780734) | `constructive algorithms` `math` `number theory` | Sep/09/2025 08:46 PM |
| 208 | [A - Shift Sort](https://codeforces.com/contest/2140/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2140/submission/337773420) | `greedy` `sortings` | Sep/09/2025 08:39 PM |
| 207 | [I - Divisability](https://codeforces.com/contest/223338/problem/I) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337770019) |  | Sep/09/2025 08:22 PM |
| 206 | [H - GCD](https://codeforces.com/contest/223338/problem/H) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337756199) |  | Sep/09/2025 06:55 PM |
| 205 | [G - Summation of its divisors](https://codeforces.com/contest/223338/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337754640) |  | Sep/09/2025 06:45 PM |
| 204 | [F - Multiplication of Matrices](https://codeforces.com/contest/223338/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337753499) |  | Sep/09/2025 06:38 PM |
| 203 | [E - Maximum Distinct Numbers](https://codeforces.com/contest/223338/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337661675) |  | Sep/08/2025 11:45 PM |
| 202 | [D - Xor](https://codeforces.com/contest/223338/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337661292) |  | Sep/08/2025 11:40 PM |
| 201 | [B - Cake Collection](https://codeforces.com/contest/2139/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2139/submission/337574081) | `greedy` | Sep/08/2025 08:47 PM |
| 200 | [A - Maple and Multiplication](https://codeforces.com/contest/2139/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2139/submission/337560151) | `greedy` `math` | Sep/08/2025 08:37 PM |
| 199 | [B - Fun Permutation](https://codeforces.com/contest/2137/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2137/submission/337453967) | `constructive algorithms` `math` `number theory` | Sep/07/2025 11:36 PM |
| 198 | [E - Mexification](https://codeforces.com/contest/2137/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2137/submission/337411469) | `brute force` `implementation` `math` | Sep/07/2025 10:10 PM |
| 197 | [D - Replace with Occurrences](https://codeforces.com/contest/2137/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2137/submission/337376682) | `constructive algorithms` | Sep/07/2025 09:38 PM |
| 196 | [C - Maximum Even Sum](https://codeforces.com/contest/2137/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2137/submission/337360597) | `brute force` `greedy` `implementation` `math` | Sep/07/2025 09:25 PM |
| 195 | [A - Collatz Conjecture](https://codeforces.com/contest/2137/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2137/submission/337298525) | `constructive algorithms` `math` | Sep/07/2025 08:44 PM |
| 194 | [C - Sum of Range](https://codeforces.com/contest/223338/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337275560) |  | Sep/07/2025 07:48 PM |
| 193 | [B - Prime checking](https://codeforces.com/contest/223338/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337217938) |  | Sep/07/2025 11:22 AM |
| 192 | [A - Power Of Two](https://codeforces.com/contest/223338/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223338/submission/337217512) |  | Sep/07/2025 11:15 AM |
| 191 | [O - Five in One](https://codeforces.com/contest/223205/problem/O) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337216981) |  | Sep/07/2025 11:06 AM |
| 190 | [N - Shift Zeros](https://codeforces.com/contest/223205/problem/N) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337169866) |  | Sep/06/2025 10:17 PM |
| 189 | [M - Distinct Numbers](https://codeforces.com/contest/223205/problem/M) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337169483) |  | Sep/06/2025 10:14 PM |
| 188 | [L - New Array](https://codeforces.com/contest/223205/problem/L) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337168287) |  | Sep/06/2025 10:04 PM |
| 187 | [K - Shift Right ](https://codeforces.com/contest/223205/problem/K) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337164947) |  | Sep/06/2025 09:36 PM |
| 186 | [J - Average ](https://codeforces.com/contest/223205/problem/J) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337160945) |  | Sep/06/2025 09:03 PM |
| 185 | [I - Swapping With Matrix](https://codeforces.com/contest/223205/problem/I) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337159504) |  | Sep/06/2025 08:52 PM |
| 184 | [H - N Times](https://codeforces.com/contest/223205/problem/H) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337158651) |  | Sep/06/2025 08:45 PM |
| 183 | [G - Max and MIN](https://codeforces.com/contest/223205/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337158219) |  | Sep/06/2025 08:42 PM |
| 182 | [F - Equation](https://codeforces.com/contest/223205/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337157843) |  | Sep/06/2025 08:39 PM |
| 181 | [E - Swap](https://codeforces.com/contest/223205/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337156971) |  | Sep/06/2025 08:32 PM |
| 180 | [D - Prime Function](https://codeforces.com/contest/223205/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337156836) |  | Sep/06/2025 08:31 PM |
| 179 | [C - Wonderful Number](https://codeforces.com/contest/223205/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337155323) |  | Sep/06/2025 08:19 PM |
| 178 | [B - Print](https://codeforces.com/contest/223205/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337115325) |  | Sep/06/2025 02:52 PM |
| 177 | [A - Add](https://codeforces.com/contest/223205/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/223205/submission/337115098) |  | Sep/06/2025 02:50 PM |
| 176 | [Y - Min Cost String](https://codeforces.com/contest/219856/problem/Y) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/337087069) |  | Sep/06/2025 09:58 AM |
| 175 | [X - Comparison ](https://codeforces.com/contest/219856/problem/X) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/337041811) |  | Sep/05/2025 10:15 PM |
| 174 | [W - Encrypt & Decrypt Message](https://codeforces.com/contest/219856/problem/W) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/337038603) |  | Sep/05/2025 09:50 PM |
| 173 | [V - Replace Word](https://codeforces.com/contest/219856/problem/V) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/337036104) |  | Sep/05/2025 09:33 PM |
| 172 | [U - New Words](https://codeforces.com/contest/219856/problem/U) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/337032608) |  | Sep/05/2025 09:08 PM |
| 171 | [T - URL](https://codeforces.com/contest/219856/problem/T) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/337031857) |  | Sep/05/2025 09:02 PM |
| 170 | [S - Max Split](https://codeforces.com/contest/219856/problem/S) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336980959) |  | Sep/05/2025 04:43 PM |
| 169 | [C - Prime Dominion](https://codeforces.com/contest/106057/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/106057/submission/336973357) |  | Sep/05/2025 03:33 PM |
| 168 | [E - Treasures in the Interval](https://codeforces.com/contest/106057/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/106057/submission/336971562) |  | Sep/05/2025 03:19 PM |
| 167 | [D - Zero is not an option!](https://codeforces.com/contest/106057/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/106057/submission/336970796) |  | Sep/05/2025 03:13 PM |
| 166 | [G - MeX is not Max](https://codeforces.com/contest/106057/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/106057/submission/336970090) |  | Sep/05/2025 03:07 PM |
| 165 | [K - Dreaming of National IUPC](https://codeforces.com/contest/106057/problem/K) | [C++20 (GCC 13-64)](https://codeforces.com/contest/106057/submission/336969799) |  | Sep/05/2025 03:05 PM |
| 164 | [A - Decreasing Trees](https://codeforces.com/contest/106057/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/106057/submission/336969655) |  | Sep/05/2025 03:04 PM |
| 163 | [R - String Score](https://codeforces.com/contest/219856/problem/R) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336967800) |  | Sep/05/2025 02:46 PM |
| 162 | [Q - Reverse Words](https://codeforces.com/contest/219856/problem/Q) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336949550) |  | Sep/05/2025 11:42 AM |
| 161 | [P - Count Words](https://codeforces.com/contest/219856/problem/P) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336948408) |  | Sep/05/2025 11:28 AM |
| 160 | [O - Sort String](https://codeforces.com/contest/219856/problem/O) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336948122) |  | Sep/05/2025 11:24 AM |
| 159 | [N - Max Subsequence](https://codeforces.com/contest/219856/problem/N) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336945160) |  | Sep/05/2025 10:53 AM |
| 158 | [M - Subsequence String](https://codeforces.com/contest/219856/problem/M) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336905207) |  | Sep/04/2025 11:16 PM |
| 157 | [L - String Functions](https://codeforces.com/contest/219856/problem/L) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336902272) |  | Sep/04/2025 10:55 PM |
| 156 | [K - I Love strings](https://codeforces.com/contest/219856/problem/K) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336884117) |  | Sep/04/2025 08:27 PM |
| 155 | [J - Count Letters](https://codeforces.com/contest/219856/problem/J) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336785091) |  | Sep/03/2025 10:54 PM |
| 154 | [I - Palindrome](https://codeforces.com/contest/219856/problem/I) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336784895) |  | Sep/03/2025 10:52 PM |
| 153 | [H - Good or Bad](https://codeforces.com/contest/219856/problem/H) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336783925) |  | Sep/03/2025 10:43 PM |
| 152 | [G - Conversion](https://codeforces.com/contest/219856/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336783546) |  | Sep/03/2025 10:39 PM |
| 151 | [F - Way Too Long Words](https://codeforces.com/contest/219856/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336783195) |  | Sep/03/2025 10:36 PM |
| 150 | [E - Count](https://codeforces.com/contest/219856/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336783053) |  | Sep/03/2025 10:35 PM |
| 149 | [D - Strings](https://codeforces.com/contest/219856/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336782954) |  | Sep/03/2025 10:34 PM |
| 148 | [C - Compare](https://codeforces.com/contest/219856/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336782829) |  | Sep/03/2025 10:32 PM |
| 147 | [B - Let's use Getline](https://codeforces.com/contest/219856/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336782204) |  | Sep/03/2025 10:27 PM |
| 146 | [A - Create A New String](https://codeforces.com/contest/219856/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219856/submission/336782063) |  | Sep/03/2025 10:25 PM |
| 145 | [G - Even Hate Odd](https://codeforces.com/contest/329103/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336781513) |  | Sep/03/2025 10:20 PM |
| 144 | [F - Front - End](https://codeforces.com/contest/329103/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336779378) |  | Sep/03/2025 10:01 PM |
| 143 | [E - Alternating Array](https://codeforces.com/contest/329103/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336779120) |  | Sep/03/2025 09:59 PM |
| 142 | [D - Counting Elements](https://codeforces.com/contest/329103/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336768072) |  | Sep/03/2025 08:21 PM |
| 141 | [C - Choose Elements](https://codeforces.com/contest/329103/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336713394) |  | Sep/03/2025 12:19 PM |
| 140 | [B - Reversing](https://codeforces.com/contest/329103/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336712259) |  | Sep/03/2025 12:06 PM |
| 139 | [A - Square or rectangle](https://codeforces.com/contest/329103/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/329103/submission/336671648) |  | Sep/03/2025 12:13 AM |
| 138 | [Z - Binary Search](https://codeforces.com/contest/219774/problem/Z) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336671184) |  | Sep/03/2025 12:09 AM |
| 137 | [Y - Range sum query](https://codeforces.com/contest/219774/problem/Y) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336670130) |  | Sep/03/2025 12:02 AM |
| 136 | [X - 8 Neighbors](https://codeforces.com/contest/219774/problem/X) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336669056) |  | Sep/02/2025 11:54 PM |
| 135 | [W - Mirror Array](https://codeforces.com/contest/219774/problem/W) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336657343) |  | Sep/02/2025 10:39 PM |
| 134 | [V - Frequency Array](https://codeforces.com/contest/219774/problem/V) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336656446) |  | Sep/02/2025 10:34 PM |
| 133 | [U - Is B a subsequence of A ?](https://codeforces.com/contest/219774/problem/U) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336656063) |  | Sep/02/2025 10:31 PM |
| 132 | [T - Matrix ](https://codeforces.com/contest/219774/problem/T) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336654887) |  | Sep/02/2025 10:24 PM |
| 131 | [S - Search In Matrix](https://codeforces.com/contest/219774/problem/S) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336654542) |  | Sep/02/2025 10:22 PM |
| 130 | [R - Permutation with arrays](https://codeforces.com/contest/219774/problem/R) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336653729) |  | Sep/02/2025 10:18 PM |
| 129 | [Q - Count Subarrays](https://codeforces.com/contest/219774/problem/Q) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336653370) |  | Sep/02/2025 10:15 PM |
| 128 | [P - Minimize Number](https://codeforces.com/contest/219774/problem/P) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336651712) |  | Sep/02/2025 10:05 PM |
| 127 | [O - Fibonacci](https://codeforces.com/contest/219774/problem/O) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336651034) |  | Sep/02/2025 10:01 PM |
| 126 | [N - Check Code](https://codeforces.com/contest/219774/problem/N) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336650260) |  | Sep/02/2025 09:56 PM |
| 125 | [M - Replace MinMax](https://codeforces.com/contest/219774/problem/M) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336648753) |  | Sep/02/2025 09:47 PM |
| 124 | [L - Max Subarray](https://codeforces.com/contest/219774/problem/L) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336647936) |  | Sep/02/2025 09:41 PM |
| 123 | [K - Sum Digits](https://codeforces.com/contest/219774/problem/K) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336620357) |  | Sep/02/2025 06:41 PM |
| 122 | [J - Lucky Array](https://codeforces.com/contest/219774/problem/J) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336620113) |  | Sep/02/2025 06:40 PM |
| 121 | [I - Smallest Pair](https://codeforces.com/contest/219774/problem/I) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336619652) |  | Sep/02/2025 06:37 PM |
| 120 | [H - Sorting](https://codeforces.com/contest/219774/problem/H) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336619202) |  | Sep/02/2025 06:34 PM |
| 119 | [G - Palindrome Array](https://codeforces.com/contest/219774/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336618971) |  | Sep/02/2025 06:33 PM |
| 118 | [F - Reversing](https://codeforces.com/contest/219774/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336616840) |  | Sep/02/2025 06:18 PM |
| 117 | [E - Lowest Number](https://codeforces.com/contest/219774/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336616664) |  | Sep/02/2025 06:17 PM |
| 116 | [D - Positions in array](https://codeforces.com/contest/219774/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336616408) |  | Sep/02/2025 06:15 PM |
| 115 | [C - Replacement](https://codeforces.com/contest/219774/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336616194) |  | Sep/02/2025 06:14 PM |
| 114 | [B - Searching](https://codeforces.com/contest/219774/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336615971) |  | Sep/02/2025 06:12 PM |
| 113 | [A - Summation](https://codeforces.com/contest/219774/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/219774/submission/336605650) |  | Sep/02/2025 04:43 PM |
| 112 | [H - Simple Mod](https://codeforces.com/contest/326907/problem/H) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/326907/submission/336603008) |  | Sep/02/2025 04:13 PM |
| 111 | [G - Construct the Sum](https://codeforces.com/contest/326907/problem/G) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/326907/submission/336573590) |  | Sep/02/2025 10:46 AM |
| 110 | [F - Break Number](https://codeforces.com/contest/326907/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/326907/submission/336536416) |  | Sep/01/2025 11:16 PM |
| 109 | [E - Hady Rides the Train](https://codeforces.com/contest/326907/problem/E) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/326907/submission/336532072) |  | Sep/01/2025 10:41 PM |
| 108 | [D - Range Sum](https://codeforces.com/contest/326907/problem/D) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/326907/submission/336529880) |  | Sep/01/2025 10:24 PM |
| 107 | [C - Finding Minimums](https://codeforces.com/contest/326907/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326907/submission/336394127) |  | Aug/31/2025 08:11 PM |
| 106 | [B - Drawing `X'](https://codeforces.com/contest/326907/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326907/submission/336393592) |  | Aug/31/2025 08:07 PM |
| 105 | [A - Timon and Pumbaa](https://codeforces.com/contest/326907/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326907/submission/336391273) |  | Aug/31/2025 07:59 PM |
| 104 | [Z - Three Numbers](https://codeforces.com/contest/219432/problem/Z) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336297292) |  | Aug/30/2025 11:58 PM |
| 103 | [Y - Easy Fibonacci](https://codeforces.com/contest/219432/problem/Y) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336295676) |  | Aug/30/2025 11:46 PM |
| 102 | [X - Convert To Decimal 2](https://codeforces.com/contest/219432/problem/X) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336295115) |  | Aug/30/2025 11:42 PM |
| 101 | [W - Shape3](https://codeforces.com/contest/219432/problem/W) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336294231) |  | Aug/30/2025 11:35 PM |
| 100 | [V - PUM](https://codeforces.com/contest/219432/problem/V) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336293720) |  | Aug/30/2025 11:32 PM |
| 99 | [U - Some Sums](https://codeforces.com/contest/219432/problem/U) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336292872) |  | Aug/30/2025 11:25 PM |
| 98 | [T - Shape2](https://codeforces.com/contest/219432/problem/T) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336292145) |  | Aug/30/2025 11:21 PM |
| 97 | [S - Sum of Consecutive Odd Numbers](https://codeforces.com/contest/219432/problem/S) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336290063) |  | Aug/30/2025 11:05 PM |
| 96 | [R - Sequence of Numbers and Sum](https://codeforces.com/contest/219432/problem/R) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336289817) |  | Aug/30/2025 11:03 PM |
| 95 | [Q - Digits](https://codeforces.com/contest/219432/problem/Q) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336289011) |  | Aug/30/2025 10:57 PM |
| 94 | [P - Shape1](https://codeforces.com/contest/219432/problem/P) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336288720) |  | Aug/30/2025 10:55 PM |
| 93 | [O - Pyramid](https://codeforces.com/contest/219432/problem/O) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336288605) |  | Aug/30/2025 10:54 PM |
| 92 | [N - Numbers Histogram](https://codeforces.com/contest/219432/problem/N) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336288294) |  | Aug/30/2025 10:52 PM |
| 91 | [M - Lucky Numbers](https://codeforces.com/contest/219432/problem/M) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336287999) |  | Aug/30/2025 10:49 PM |
| 90 | [L - GCD](https://codeforces.com/contest/219432/problem/L) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336286042) |  | Aug/30/2025 10:35 PM |
| 89 | [K - Divisors](https://codeforces.com/contest/219432/problem/K) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336282561) |  | Aug/30/2025 10:10 PM |
| 88 | [J - Primes from 1 to n](https://codeforces.com/contest/219432/problem/J) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336282073) |  | Aug/30/2025 10:06 PM |
| 87 | [I - Palindrome](https://codeforces.com/contest/219432/problem/I) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336281115) |  | Aug/30/2025 09:58 PM |
| 86 | [H - One Prime](https://codeforces.com/contest/219432/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336279982) |  | Aug/30/2025 09:48 PM |
| 85 | [G - Factorial](https://codeforces.com/contest/219432/problem/G) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336279458) |  | Aug/30/2025 09:43 PM |
| 84 | [F - Multiplication table](https://codeforces.com/contest/219432/problem/F) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336278380) |  | Aug/30/2025 09:34 PM |
| 83 | [E - Max](https://codeforces.com/contest/219432/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336278182) |  | Aug/30/2025 09:32 PM |
| 82 | [D - Fixed Password](https://codeforces.com/contest/219432/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336277972) |  | Aug/30/2025 09:30 PM |
| 81 | [C - Even, Odd, Positive and Negative](https://codeforces.com/contest/219432/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336277016) |  | Aug/30/2025 09:22 PM |
| 80 | [B - Even Numbers](https://codeforces.com/contest/219432/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336276276) |  | Aug/30/2025 09:16 PM |
| 79 | [A - 1 to N](https://codeforces.com/contest/219432/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219432/submission/336276024) |  | Aug/30/2025 09:14 PM |
| 78 | [I - Lucky Numbers](https://codeforces.com/contest/326175/problem/I) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336272845) |  | Aug/30/2025 08:44 PM |
| 77 | [H - Data Type Guessing](https://codeforces.com/contest/326175/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336272302) |  | Aug/30/2025 08:39 PM |
| 76 | [G - Katryoshka](https://codeforces.com/contest/326175/problem/G) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336271074) |  | Aug/30/2025 08:30 PM |
| 75 | [F - Adding Bits](https://codeforces.com/contest/326175/problem/F) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336269118) |  | Aug/30/2025 08:15 PM |
| 74 | [E - Interval Sweep](https://codeforces.com/contest/326175/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336267717) |  | Aug/30/2025 08:03 PM |
| 73 | [D - Ali Baba and Puzzles](https://codeforces.com/contest/326175/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336267209) |  | Aug/30/2025 07:58 PM |
| 72 | [C - Next Alphabet](https://codeforces.com/contest/326175/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336266870) |  | Aug/30/2025 07:55 PM |
| 71 | [B - Memo and Momo](https://codeforces.com/contest/326175/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336266611) |  | Aug/30/2025 07:53 PM |
| 70 | [A - Winter Sale](https://codeforces.com/contest/326175/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/326175/submission/336266332) |  | Aug/30/2025 07:50 PM |
| 69 | [Z - Hard Compare](https://codeforces.com/contest/219158/problem/Z) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336153770) |  | Aug/29/2025 09:15 PM |
| 68 | [Y - The last 2 digits](https://codeforces.com/contest/219158/problem/Y) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336150888) |  | Aug/29/2025 08:54 PM |
| 67 | [X - Two intervals](https://codeforces.com/contest/219158/problem/X) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336150001) |  | Aug/29/2025 08:47 PM |
| 66 | [W - Mathematical Expression](https://codeforces.com/contest/219158/problem/W) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336149299) |  | Aug/29/2025 08:42 PM |
| 65 | [V - Comparison](https://codeforces.com/contest/219158/problem/V) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336145783) |  | Aug/29/2025 08:16 PM |
| 64 | [U - Float or int](https://codeforces.com/contest/219158/problem/U) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336142006) |  | Aug/29/2025 07:50 PM |
| 63 | [T - Sort Numbers](https://codeforces.com/contest/219158/problem/T) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336141578) |  | Aug/29/2025 07:48 PM |
| 62 | [S - Interval](https://codeforces.com/contest/219158/problem/S) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336140805) |  | Aug/29/2025 07:43 PM |
| 61 | [R - Age in Days](https://codeforces.com/contest/219158/problem/R) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336140179) |  | Aug/29/2025 07:39 PM |
| 60 | [Q - Coordinates of a Point](https://codeforces.com/contest/219158/problem/Q) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336139775) |  | Aug/29/2025 07:37 PM |
| 59 | [P - First digit !](https://codeforces.com/contest/219158/problem/P) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336138919) |  | Aug/29/2025 07:31 PM |
| 58 | [O - Calculator](https://codeforces.com/contest/219158/problem/O) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336138469) |  | Aug/29/2025 07:28 PM |
| 57 | [N - Char](https://codeforces.com/contest/219158/problem/N) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336137380) |  | Aug/29/2025 07:20 PM |
| 56 | [M - Capital or Small or Digit](https://codeforces.com/contest/219158/problem/M) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336136306) |  | Aug/29/2025 07:13 PM |
| 55 | [L - The Brothers](https://codeforces.com/contest/219158/problem/L) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336128799) |  | Aug/29/2025 06:12 PM |
| 54 | [K - Max and Min](https://codeforces.com/contest/219158/problem/K) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336128658) |  | Aug/29/2025 06:10 PM |
| 53 | [J - Multiples](https://codeforces.com/contest/219158/problem/J) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336128554) |  | Aug/29/2025 06:09 PM |
| 52 | [I - Welcome for you with Conditions](https://codeforces.com/contest/219158/problem/I) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336128405) |  | Aug/29/2025 06:08 PM |
| 51 | [H - Two numbers](https://codeforces.com/contest/219158/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336128229) |  | Aug/29/2025 06:07 PM |
| 50 | [G - Summation from 1 to N](https://codeforces.com/contest/219158/problem/G) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336127196) |  | Aug/29/2025 06:00 PM |
| 49 | [F - Digits Summation](https://codeforces.com/contest/219158/problem/F) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336126933) |  | Aug/29/2025 05:58 PM |
| 48 | [E - Area of a Circle](https://codeforces.com/contest/219158/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336126651) |  | Aug/29/2025 05:56 PM |
| 47 | [D -  Difference](https://codeforces.com/contest/219158/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336126435) |  | Aug/29/2025 05:55 PM |
| 46 | [C - Simple Calculator](https://codeforces.com/contest/219158/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336125995) |  | Aug/29/2025 05:52 PM |
| 45 | [B - Basic Data Types](https://codeforces.com/contest/219158/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/219158/submission/336125628) |  | Aug/29/2025 05:49 PM |
| 44 | [U - Knapsack ](https://codeforces.com/contest/223339/problem/U) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336106139) |  | Aug/29/2025 02:47 PM |
| 43 | [T - Combination](https://codeforces.com/contest/223339/problem/T) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336092464) |  | Aug/29/2025 12:33 PM |
| 42 | [S - Array Average](https://codeforces.com/contest/223339/problem/S) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336090438) |  | Aug/29/2025 12:14 PM |
| 41 | [R - Palindrome Array](https://codeforces.com/contest/223339/problem/R) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336090028) |  | Aug/29/2025 12:09 PM |
| 40 | [Q - 3n + 1 sequence](https://codeforces.com/contest/223339/problem/Q) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336089097) |  | Aug/29/2025 12:00 PM |
| 39 | [P - Log2](https://codeforces.com/contest/223339/problem/P) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336088205) |  | Aug/29/2025 11:50 AM |
| 38 | [N - Sum of a Matrix](https://codeforces.com/contest/223339/problem/N) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336087406) |  | Aug/29/2025 11:41 AM |
| 37 | [M - Suffix Sum](https://codeforces.com/contest/223339/problem/M) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336085447) |  | Aug/29/2025 11:23 AM |
| 36 | [L - Summation](https://codeforces.com/contest/223339/problem/L) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336085232) |  | Aug/29/2025 11:21 AM |
| 35 | [K - Max Number](https://codeforces.com/contest/223339/problem/K) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336085145) |  | Aug/29/2025 11:20 AM |
| 34 | [J - Factorial](https://codeforces.com/contest/223339/problem/J) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336084936) |  | Aug/29/2025 11:17 AM |
| 33 | [I - Count Vowels](https://codeforces.com/contest/223339/problem/I) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336084718) |  | Aug/29/2025 11:15 AM |
| 32 | [H - Inverted Pyramid ](https://codeforces.com/contest/223339/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336084097) |  | Aug/29/2025 11:07 AM |
| 31 | [G - Pyramid](https://codeforces.com/contest/223339/problem/G) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336082624) |  | Aug/29/2025 10:47 AM |
| 30 | [F - Print Even Indices](https://codeforces.com/contest/223339/problem/F) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336057383) |  | Aug/29/2025 02:30 AM |
| 29 | [E - Base Converssion](https://codeforces.com/contest/223339/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336056464) |  | Aug/29/2025 02:19 AM |
| 28 | [C - Print from N to 1](https://codeforces.com/contest/223339/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336054845) |  | Aug/29/2025 01:58 AM |
| 27 | [B - Print from 1 to N](https://codeforces.com/contest/223339/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336054506) |  | Aug/29/2025 01:55 AM |
| 26 | [A - Print Recursion](https://codeforces.com/contest/223339/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336054411) |  | Aug/29/2025 01:54 AM |
| 25 | [D - Print Digits using Recursion](https://codeforces.com/contest/223339/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336054317) |  | Aug/29/2025 01:53 AM |
| 24 | [A - Against the Difference](https://codeforces.com/contest/2135/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2135/submission/336052309) | `data structures` `dp` | Aug/29/2025 01:34 AM |
| 23 | [O - Fibonacci](https://codeforces.com/contest/223339/problem/O) | [C++17 (GCC 7-32)](https://codeforces.com/contest/223339/submission/336050005) |  | Aug/29/2025 12:51 AM |
| 22 | [C - Against the Difference](https://codeforces.com/contest/2136/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2136/submission/336007876) | `data structures` `dp` | Aug/28/2025 10:01 PM |
| 21 | [B - Like the Bitset](https://codeforces.com/contest/2136/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2136/submission/335972526) | `constructive algorithms` `greedy` `two pointers` | Aug/28/2025 09:04 PM |
| 20 | [A - In the Dream](https://codeforces.com/contest/2136/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2136/submission/335951567) | `greedy` `math` | Aug/28/2025 08:44 PM |
| 19 | [ZB - Subarray Sums II](https://codeforces.com/contest/102961/problem/ZB) | [C++17 (GCC 7-32)](https://codeforces.com/contest/102961/submission/320934003) |  | May/23/2025 10:38 PM |
| 18 | [U - Factory Machines](https://codeforces.com/contest/102961/problem/U) | [C++17 (GCC 7-32)](https://codeforces.com/contest/102961/submission/320926157) |  | May/23/2025 09:39 PM |
| 17 | [M - Playlist](https://codeforces.com/contest/102961/problem/M) | [C++17 (GCC 7-32)](https://codeforces.com/contest/102961/submission/320892435) |  | May/23/2025 05:15 PM |
| 16 | [H - Maximum Subarray Sum](https://codeforces.com/contest/102961/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/102961/submission/320656966) |  | May/21/2025 08:12 PM |
| 15 | [B - The Last Bit of Us](https://codeforces.com/contest/105884/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/105884/submission/319450707) |  | May/13/2025 08:23 AM |
| 14 | [H - Litmus Test](https://codeforces.com/contest/105884/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/105884/submission/319431720) |  | May/13/2025 01:00 AM |
| 13 | [D - An Interesting Problem](https://codeforces.com/contest/105884/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/105884/submission/319431298) |  | May/13/2025 12:55 AM |
| 12 | [H - Blurry Vision](https://codeforces.com/contest/2095/problem/H) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/317988764) | `*special` `fft` `math` | May/01/2025 09:34 PM |
| 11 | [J - Premiere at a Wrong Time](https://codeforces.com/contest/2095/problem/J) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/317985507) | `*special` | May/01/2025 09:27 PM |
| 10 | [F - ⅓ оf а Рrоblеm](https://codeforces.com/contest/2095/problem/F) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/317865415) | `*special` `math` | Apr/30/2025 10:52 PM |
| 9 | [D - Where Am I?](https://codeforces.com/contest/2095/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/317864101) | `*special` `geometry` | Apr/30/2025 10:38 PM |
| 8 | [C - Would It Be Unrated?](https://codeforces.com/contest/2095/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/317864019) | `*special` `binary search` `brute force` | Apr/30/2025 10:37 PM |
| 7 | [B - Plinko](https://codeforces.com/contest/2095/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/317863913) | `*special` `games` `interactive` | Apr/30/2025 10:36 PM |
| 6 | [E - Aloy and the Forbidden Code](https://codeforces.com/contest/105723/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/105723/submission/317503205) |  | Apr/28/2025 01:16 AM |
| 5 | [B - 8 Queens, Again!!](https://codeforces.com/contest/100947/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/100947/submission/316957661) |  | Apr/24/2025 06:12 PM |
| 4 | [A - Piecing It Together](https://codeforces.com/contest/2095/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2095/submission/313383209) | `*special` `string suffix structures` | Apr/01/2025 08:36 PM |
| 3 | [A - Maximum Distance](https://codeforces.com/contest/102951/problem/A) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/102951/submission/304571356) |  | Feb/05/2025 08:17 PM |
| 2 | [B - Studying Algorithms](https://codeforces.com/contest/102951/problem/B) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/102951/submission/303551293) |  | Jan/29/2025 11:24 PM |
| 1 | [A - Say Hello With C++](https://codeforces.com/contest/219158/problem/A) | [C++20 (GCC 11-64)](https://codeforces.com/contest/219158/submission/233140924) |  | Nov/17/2023 09:25 PM |