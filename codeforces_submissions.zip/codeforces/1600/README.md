# Codeforces 1600 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 17 | [D - From 1 to Infinity](https://codeforces.com/contest/2132/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2132/submission/334928078) | `binary search` `dp` `implementation` `math` `*1600` | Aug/21/2025 10:32 PM |
| 16 | [A - Little Pony and Expected Maximum](https://codeforces.com/contest/453/problem/A) | [C++17 (GCC 7-32)](https://codeforces.com/contest/453/submission/334553640) | `probabilities` `*1600` | Aug/19/2025 09:01 PM |
| 15 | [C - Hockey](https://codeforces.com/contest/96/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/96/submission/334116191) | `implementation` `strings` `*1600` | Aug/16/2025 12:39 AM |
| 14 | [C - Hometask](https://codeforces.com/contest/155/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/155/submission/334010475) | `dp` `greedy` `*1600` | Aug/15/2025 10:50 AM |
| 13 | [C - Mafia](https://codeforces.com/contest/349/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/349/submission/333834384) | `implementation` `*1600` | Aug/13/2025 11:14 PM |
| 12 | [B - Stay or Mirror](https://codeforces.com/contest/2129/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2129/submission/331888662) | `brute force` `data structures` `dp` `greedy` `sortings` `*1600` | Aug/01/2025 08:32 AM |
| 11 | [D - Stay or Mirror](https://codeforces.com/contest/2130/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2130/submission/331834730) | `data structures` `greedy` `*1600` | Jul/31/2025 10:39 PM |
| 10 | [C - Day at the Beach](https://codeforces.com/contest/599/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/599/submission/331448886) | `sortings` `*1600` | Jul/29/2025 07:10 PM |
| 9 | [D - Sum of LDS](https://codeforces.com/contest/2128/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2128/submission/331306224) | `brute force` `combinatorics` `dp` `greedy` `math` `*1600` | Jul/28/2025 08:23 PM |
| 8 | [C - Parsa's Humongous Tree](https://codeforces.com/contest/1529/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1529/submission/330634489) | `dfs and similar` `dp` `graphs` `greedy` `trees` `*1600` | Jul/24/2025 08:52 PM |
| 7 | [D - Segments Covering](https://codeforces.com/contest/2125/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2125/submission/330355658) | `dp` `math` `probabilities` `*1600` | Jul/22/2025 09:10 PM |
| 6 | [C - Strange Test](https://codeforces.com/contest/1632/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1632/submission/330164437) | `binary search` `bitmasks` `brute force` `dp` `math` `*1600` | Jul/21/2025 09:11 PM |
| 5 | [C - Job Interview](https://codeforces.com/contest/1976/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1976/submission/328910463) | `binary search` `dp` `greedy` `implementation` `two pointers` `*1600` | Jul/14/2025 07:36 PM |
| 4 | [C - Binary String Copying](https://codeforces.com/contest/1849/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1849/submission/328678319) | `binary search` `brute force` `data structures` `hashing` `strings` `*1600` | Jul/12/2025 09:17 PM |
| 3 | [C - Set or Decrease](https://codeforces.com/contest/1622/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1622/submission/328402624) | `binary search` `brute force` `greedy` `sortings` `*1600` | Jul/10/2025 09:34 PM |
| 2 | [C - Sequence Master](https://codeforces.com/contest/1806/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1806/submission/327260003) | `brute force` `constructive algorithms` `math` `*1600` | Jul/03/2025 09:31 PM |
| 1 | [B - Floor or Ceil](https://codeforces.com/contest/2082/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2082/submission/326420947) | `brute force` `greedy` `*1600` | Jun/28/2025 08:28 PM |