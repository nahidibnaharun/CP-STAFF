# Codeforces 2300 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 2 | [E - Grid Xor](https://codeforces.com/contest/1629/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1629/submission/332500479) | `constructive algorithms` `greedy` `interactive` `math` `*2300` | Aug/05/2025 06:20 PM |
| 1 | [C3 - Interactive RBS (Hard Version)](https://codeforces.com/contest/2129/problem/C3) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2129/submission/332245584) | `binary search` `bitmasks` `constructive algorithms` `dp` `interactive` `*2300` | Aug/03/2025 09:28 PM |