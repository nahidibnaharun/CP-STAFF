# Codeforces 1900 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 2 | [F - Unjust Binary Life](https://codeforces.com/contest/2131/problem/F) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2131/submission/333439075) | `binary search` `data structures` `greedy` `greedy` `math` `sortings` `two pointers` `*1900` | Aug/10/2025 10:42 PM |
| 1 | [C1 - Interactive RBS (Easy Version)](https://codeforces.com/contest/2129/problem/C1) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2129/submission/332166887) | `binary search` `bitmasks` `constructive algorithms` `interactive` `*1900` | Aug/03/2025 08:42 AM |