# Codeforces 1800 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 6 | [E - Office Keys](https://codeforces.com/contest/302977/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/302977/submission/334695370) | `*1800` | Aug/20/2025 10:32 PM |
| 5 | [D - Exam in MAC](https://codeforces.com/contest/1935/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1935/submission/331858894) | `binary search` `combinatorics` `implementation` `math` `*1800` | Aug/01/2025 12:08 AM |
| 4 | [C - Messenger in MAC](https://codeforces.com/contest/1935/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1935/submission/331858852) | `binary search` `brute force` `constructive algorithms` `data structures` `dp` `greedy` `sortings` `*1800` | Aug/01/2025 12:07 AM |
| 3 | [C - Mikasa](https://codeforces.com/contest/1554/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1554/submission/330009221) | `binary search` `bitmasks` `greedy` `implementation` `*1800` | Jul/20/2025 10:22 PM |
| 2 | [C - Recover an RBS](https://codeforces.com/contest/1709/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1709/submission/329205645) | `constructive algorithms` `greedy` `implementation` `strings` `*1800` | Jul/16/2025 08:14 PM |
| 1 | [C - Nauuo and Cards](https://codeforces.com/contest/1173/problem/C) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/1173/submission/285462682) | `binary search` `greedy` `implementation` `*1800` | Oct/12/2024 07:15 PM |