# Codeforces 2100 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 2 | [F1 - Game on Sum (Easy Version)](https://codeforces.com/contest/1629/problem/F1) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1629/submission/332521342) | `combinatorics` `dp` `games` `*2100` | Aug/05/2025 08:45 PM |
| 1 | [E - Make it Zero](https://codeforces.com/contest/2124/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2124/submission/327968117) | `constructive algorithms` `greedy` `math` `*2100` | Jul/07/2025 09:29 PM |