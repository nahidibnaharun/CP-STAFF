# Codeforces 2000 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 1 | [C2 - Interactive RBS (Medium Version)](https://codeforces.com/contest/2129/problem/C2) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2129/submission/332167383) | `binary search` `bitmasks` `constructive algorithms` `interactive` `*2000` | Aug/03/2025 08:50 AM |