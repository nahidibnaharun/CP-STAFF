# Codeforces 1700 Rating Submissions

| # | Title | Solution | Tags | Submitted |
|:-:|-------|----------|------|-----------|
| 9 | [C - Geometric Progression](https://codeforces.com/contest/567/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/567/submission/334400039) | `binary search` `data structures` `dp` `*1700` | Aug/18/2025 08:00 PM |
| 8 | [C - Jzzhu and Chocolate](https://codeforces.com/contest/450/problem/C) | [C++17 (GCC 7-32)](https://codeforces.com/contest/450/submission/334285084) | `greedy` `implementation` `*1700` | Aug/17/2025 09:27 PM |
| 7 | [B - Color the Fence](https://codeforces.com/contest/349/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/349/submission/333833240) | `data structures` `dp` `greedy` `implementation` `*1700` | Aug/13/2025 11:05 PM |
| 6 | [D - Soldier and Number Game](https://codeforces.com/contest/546/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/546/submission/333539545) | `constructive algorithms` `dp` `math` `number theory` `*1700` | Aug/11/2025 06:19 PM |
| 5 | [D - Peculiar Movie Preferences](https://codeforces.com/contest/1629/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1629/submission/332462098) | `greedy` `strings` `*1700` | Aug/05/2025 01:29 PM |
| 4 | [B - Cobb](https://codeforces.com/contest/1554/problem/B) | [C++17 (GCC 7-32)](https://codeforces.com/contest/1554/submission/330008522) | `bitmasks` `brute force` `greedy` `math` `*1700` | Jul/20/2025 10:16 PM |
| 3 | [D - Make a Palindrome](https://codeforces.com/contest/2124/problem/D) | [C++17 (GCC 7-32)](https://codeforces.com/contest/2124/submission/327966107) | `greedy` `sortings` `two pointers` `*1700` | Jul/07/2025 09:13 PM |
| 2 | [E - Yet Another Task with Queens](https://codeforces.com/contest/131/problem/E) | [C++17 (GCC 7-32)](https://codeforces.com/contest/131/submission/317122195) | `sortings` `*1700` | Apr/25/2025 08:46 AM |
| 1 | [F - Skibidus and Slay](https://codeforces.com/contest/2065/problem/F) | [C++23 (GCC 14-64, msys2)](https://codeforces.com/contest/2065/submission/305243871) | `data structures` `dfs and similar` `graphs` `greedy` `trees` `*1700` | Feb/09/2025 09:25 PM |